gsap.to(".box1, .box2, .box3", {
    y: 70,
    duration: 4,
    repeat: -1,
    yoyo:true,
})